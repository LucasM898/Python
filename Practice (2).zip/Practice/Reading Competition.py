student = 530
classroom = student * 30
print(classroom)
school = classroom * 12
print(school)
goal = 10000
pagesperstudent = goal / 360
print(pagesperstudent)
