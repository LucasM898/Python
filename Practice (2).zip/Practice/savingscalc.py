earningsgoal = input("How much money do you want to save?")
numbergoal = int(earningsgoal)
months = numbergoal / 12
weeks = numbergoal / 52
days = numbergoal / 365
roundmonths = round(months, 2)
finalmonths = str(roundmonths)
print("To save up " + earningsgoal + " in one year, you will need to save " + finalmonths + " per month.")
roundweeks = round(weeks, 2)
finalweeks = str(roundweeks)
print("To save up " + earningsgoal + " in one year, you will need to save " + finalweeks + " per week.")
rounddays = round(days, 2)
finaldays = str(rounddays)
print("To save up " + earningsgoal + " in one year, you will need to save " + finaldays + " per day.")